# Mod Install Template

import os
import sys
import requests

# Mod variables

modnames = ["Assembly-CSharp.dll"]
user = "eham123"
repo = "mod-template"

moddir = os.path.dirname(os.path.abspath(sys.executable))

# Request latest version

print("Checking for updates...")
print("")

for mod in modnames:
    with open(rf"{moddir}\config\version.icfg", "r") as versionfile:
        installedver = versionfile.read()

    with open(rf"{moddir}\config\assembly-filepath.icfg", "r") as assemblypathfile:
        assemblypath = assemblypathfile.read()

    url = f"https://api.github.com/repos/{user}/{repo}/releases/latest"
    response = requests.get(url)
    data = response.json()
    latestver = data.get("tag_name")

    # Download latest version

    if installedver == latestver:
        print(f"{mod} up to date (version {installedver})")
    else:
        print(f"Downloading latest {mod} (version {latestver})...")

        os.system(rf'curl -L https://github.com/{user}/{repo}/releases/download/{latestver}/{mod} -o "{assemblypath}"')
        

        with open(rf"{moddir}\config\version.icfg", "w") as versionfile:
            versionfile.write(latestver)

        print("Downloaded latest version.")

print("")
input("Finished installation, press enter to exit.")